-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: pm
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `emby`
--

DROP TABLE IF EXISTS `emby`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emby` (
  `tg` bigint(255) NOT NULL,
  `embyid` char(255) DEFAULT NULL,
  `name` char(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pwd` char(255) DEFAULT NULL,
  `pwd2` char(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `lv` char(255) CHARACTER SET utf8mb4 NOT NULL,
  `cr` datetime DEFAULT NULL,
  `ex` datetime DEFAULT NULL,
  `us` int(255) NOT NULL DEFAULT '0',
  `iv` int(255) DEFAULT '0',
  PRIMARY KEY (`tg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emby`
--

LOCK TABLES `emby` WRITE;
/*!40000 ALTER TABLE `emby` DISABLE KEYS */;
/*!40000 ALTER TABLE `emby` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invite`
--

DROP TABLE IF EXISTS `invite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invite` (
  `id` char(255) NOT NULL,
  `tg` int(255) DEFAULT NULL,
  `us` int(255) DEFAULT NULL,
  `used` int(11) DEFAULT NULL,
  `usedtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invite`
--

LOCK TABLES `invite` WRITE;
/*!40000 ALTER TABLE `invite` DISABLE KEYS */;
/*!40000 ALTER TABLE `invite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `susu`
--

DROP TABLE IF EXISTS `susu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `susu` (
  `USER_ID` bigint(255) NOT NULL,
  `USER_N` char(255) NOT NULL,
  `USER_FN` char(255) CHARACTER SET utf8mb4 NOT NULL,
  `BLOCK` int(1) NOT NULL,
  `CR_DATE` datetime NOT NULL,
  PRIMARY KEY (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `susu`
--

LOCK TABLES `susu` WRITE;
/*!40000 ALTER TABLE `susu` DISABLE KEYS */;
/*!40000 ALTER TABLE `susu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'pm'
--

--
-- Dumping routines for database 'pm'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-26 11:11:37
